import xbmcaddon
import base64

CHBase = base64.decodestring('aHR0cDovL2NpbmVvbmRlbWFuZC5uZXQvb25kZW1hbmQvSE9NRS50eHQ=')
addon = xbmcaddon.Addon('plugin.video.cine.onDemand')